<template>

<div class="col-lg-9 col-md-9">
  
    <div>
        <slot />
    </div>
    
</div>


</template>


<script>

    export default {

    }

</script>