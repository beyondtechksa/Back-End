<template>
    <div class="tab-pane text-muted" id="maintab2" role="tabpanel">
        <div class=""></div>
    </div>
</template>


<script>
    export default{
        props:{
            form:Object,
        }
    }
</script>